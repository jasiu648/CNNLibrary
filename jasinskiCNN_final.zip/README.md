Example usage with results can be found in /src/example.ipynb
Documentation report can be found in docs/report.pdf
